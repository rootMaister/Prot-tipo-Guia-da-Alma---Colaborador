# @guia-da-alma/ds

Design system for Guia da Alma — React components, design tokens, and Storybook documentation.

**Package registry:** GitHub Package Registry (private)  
**Package manager:** pnpm (always — never npm or yarn)

---

## Table of Contents

- [Getting Started](#getting-started)
- [Project Structure](#project-structure)
- [Development](#development)
- [Design Tokens](#design-tokens)
- [Components](#components)
- [Storybook](#storybook)
- [Testing](#testing)
- [Versioning & Releasing](#versioning--releasing)
- [Consuming the Package](#consuming-the-package)

---

## Getting Started

```bash
pnpm install
pnpm dev        # Build in watch mode
pnpm storybook  # Open Storybook at localhost:6006
```

> **Node & pnpm:** Use the versions specified in the root `.nvmrc` / `package.json#engines` if present. When in doubt, use Node 20+ and pnpm 9+.

---

## Project Structure

```
design-system/
├── .ai/                   # Project rules — read this first
│   ├── CONVENTIONS.md     # Naming, React, styling, testing rules (non-negotiable)
│   ├── STRUCTURE.md       # Architecture overview
│   └── MIGRATION.md       # Token rename/migration reference
├── .changeset/            # Versioning changesets
├── .storybook/            # Storybook config
├── src/
│   ├── components/        # UI components (one folder per component)
│   ├── tokens/            # CSS design tokens
│   ├── hooks/             # Shared hooks
│   ├── utils/             # Utilities (cn, etc.)
│   ├── theme-provider/    # Light/dark mode provider
│   └── index.ts           # Single public export — all components exported here
├── tsup.config.ts         # Build config (ESM + CJS)
├── vitest.config.ts       # Test config
├── tailwind.css           # Global styles entry (imports tokens + Tailwind)
└── components.json        # shadcn/ui config
```

**The `.ai/` folder is the source of truth for all conventions.** Read `CONVENTIONS.md` before writing any code.

---

## Development

### Scripts

| Command | Description |
|---|---|
| `pnpm dev` | Build in watch mode |
| `pnpm build` | Build for production (ESM + CJS) |
| `pnpm storybook` | Run Storybook at `localhost:6006` |
| `pnpm build-storybook` | Build Storybook as static files |
| `pnpm test` | Run tests in watch mode |
| `pnpm test:run` | Run tests once (CI) |
| `pnpm lint` | Lint TypeScript files |
| `pnpm format` | Auto-format with Prettier |
| `pnpm changeset` | Create a version changeset |
| `pnpm release` | Build + publish to GitHub Package Registry |

### Adding a Component

Each component lives in its own folder under `src/components/`:

```
src/components/my-component/
├── my-component.tsx        # Implementation (named export, no default export)
├── my-component.stories.tsx # Storybook stories (CSF3)
├── my-component.test.tsx    # Vitest + React Testing Library
└── index.ts                 # Re-export
```

**Component template:**

```tsx
import React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '@/utils/cn'

const myComponentVariants = cva('base-classes', {
  variants: {
    variant: { primary: '...', secondary: '...' },
    size: { sm: '...', md: '...' },
  },
  defaultVariants: { variant: 'primary', size: 'md' },
})

export interface MyComponentProps
  extends React.ComponentPropsWithoutRef<'div'>,
    VariantProps<typeof myComponentVariants> {}

export const MyComponent = React.forwardRef<HTMLDivElement, MyComponentProps>(
  ({ variant, size, className, ...props }, ref) => (
    <div ref={ref} className={cn(myComponentVariants({ variant, size }), className)} {...props} />
  ),
)
MyComponent.displayName = 'MyComponent'
```

After creating the component, **export it from `src/index.ts`**.

### Naming Conventions

| Item | Convention | Example |
|---|---|---|
| Files / Folders | kebab-case | `date-picker.tsx`, `date-picker/` |
| CSS tokens | `--kebab-case` | `--color-action-primary` |
| React components | PascalCase | `DatePicker` |
| Props types | PascalCase | `DatePickerProps` |
| Hooks | camelCase + `use` prefix | `useToast` |
| Event handlers | `handle` prefix | `handleClick` |

### Import Order (enforced by ESLint)

```ts
import React from 'react'                         // 1. React

import { cva } from 'class-variance-authority'    // 2. External packages
import * as RadixDialog from '@radix-ui/react-dialog'

import { cn } from '@/utils/cn'                   // 3. Internal aliases

import { myHelper } from './my-helper'             // 4. Relative (same folder only)
```

---

## Design Tokens

Tokens live in `src/tokens/` and are imported via `tailwind.css`. They use CSS custom properties exposed as Tailwind utilities via `@theme`.

### Two-Tier System

**Tier 1 — Primitives** (`primitives.css`): Raw hex values. Never use these directly in components.

```css
--color-primary-500: #22c55e;
```

**Tier 2 — Semantic tokens** (`colors.css`, `typography.css`, `spacing.css`, `shadows.css`): Named by intent. Always use these in components.

```css
/* use these */
bg-action-primary
text-text-primary
border-border-default
```

### Token Groups

- **Action:** `action-primary`, `action-secondary`, `action-tertiary` + hover/subtle variants
- **Surface:** `surface-default`, `surface-subtle`, `surface-muted`, `surface-strong`
- **Text:** `text-primary`, `text-secondary`, `text-tertiary`, `text-disabled`, `text-inverse`
- **Border:** `border-default`, `border-subtle`, `border-strong`, `border-brand`
- **Feedback:** `error`, `warning`, `success`, `info` — each with surface/border/text/icon/solid variants
- **Typography:** `font-family-display` (Poppins), `font-family-body` (DM Sans)
- **Shadows:** `shadow-xs` through `shadow-2xl`

### Dark Mode

Semantic tokens own their `.dark {}` overrides. `ThemeProvider` applies the `dark` class to `<html>` and persists the user's choice in `localStorage`.

```tsx
<ThemeProvider defaultTheme="light" storageKey="my-app-theme">
  <TooltipProvider>
    <App />
  </TooltipProvider>
</ThemeProvider>
```

Use `useTheme()` to read or change the theme programmatically.

---

## Components

All 23 components are exported from a single entry point:

```ts
import { Button, Input, Dialog, useToast } from '@guia-da-alma/ds'
```

### Available Components

| Component | Description |
|---|---|
| `Alert` + `useAlert` | Status messages |
| `Avatar` + `AvatarGroup` | User images with fallback |
| `Badge` | Status indicators |
| `Button` | Primary action button |
| `Calendar` | Date calendar with event support |
| `Checkbox` + `CheckboxField` | Checkbox input |
| `Chip` | Removable tag |
| `DatePicker`, `DateRangePicker`, `InlineDatePicker` | Date selection |
| `Dialog` | Modal (with 10+ sub-components) |
| `DropdownMenu` | Menu (with 15+ sub-components) |
| `FileUploader` + `useFileUploader` | File upload with hook |
| `Input` + `InputField` | Text input |
| `MonthCalendar` | Month-only picker |
| `Popover` | Floating content |
| `Radio` + `RadioGroup` + `RadioField` | Radio buttons |
| `Select` + `SelectField` | Dropdown select |
| `Switch` + `SwitchField` | Toggle switch |
| `Textarea` + `TextareaField` | Multi-line text |
| `Toast` + `Toaster` + `useToast` | Notifications |
| `Tooltip` + `SimpleTooltip` | Hover hints |
| `ThemeProvider` + `useTheme` | Light/dark mode |

### Styling Rules

- **Tailwind-first**: use Tailwind utilities for everything
- **Semantic tokens**: always use `text-text-primary`, not `text-green-500`
- **CVA for variants**: when a component has distinct visual states
- **`cn()` for one-offs**: conditional or merged class names
- **Never inline styles** (except dynamic CSS variable overrides)
- **Dark mode**: handled by semantic tokens — avoid hardcoding `dark:` colors

---

## Storybook

Every component has a `.stories.tsx` file following CSF3:

```tsx
import type { Meta, StoryObj } from '@storybook/react'
import { Button } from './button'

const meta: Meta<typeof Button> = {
  component: Button,
  tags: ['autodocs'],
}
export default meta

type Story = StoryObj<typeof Button>

export const Primary: Story = {
  args: { children: 'Button', variant: 'primary' },
}
```

- One story per meaningful variant
- `tags: ['autodocs']` generates API documentation automatically
- All stories are wrapped in `ThemeProvider` + `TooltipProvider` by default

---

## Testing

**Stack:** Vitest + React Testing Library + jsdom

```bash
pnpm test        # Watch mode
pnpm test:run    # Single run (CI)
```

### Naming convention

```ts
it('should <expected behavior> when <condition>')

it('should show an error icon when variant is error')
it('should be disabled when the disabled prop is true')
```

### Query preferences

```ts
// Preferred — semantic queries
screen.getByRole('button', { name: /submit/i })
screen.getByLabelText('Email address')

// Last resort
screen.getByTestId('submit-btn')
```

### Minimum coverage per component

1. Renders without crashing
2. Passes axe accessibility check
3. Tests for each interactive/variant state

---

## Versioning & Releasing

This project uses **[Changesets](https://github.com/changesets/changesets)** for semantic versioning.

### Bump types

| Type | When to use |
|---|---|
| `patch` | Bug fixes, visual tweaks, token adjustments |
| `minor` | New components, new props, new token groups |
| `major` | Breaking changes (removed exports, renamed APIs) |

### Workflow

**Step 1 — Create a changeset while developing:**

```bash
pnpm changeset
```

The interactive CLI will ask you for the bump type and a summary. Commit the generated `.changeset/*.md` file with your PR.

**Step 2 — Release:**

```bash
pnpm release
```

This runs `pnpm build && changeset publish`, which:
- Bumps the version in `package.json`
- Generates/updates `CHANGELOG.md`
- Publishes to GitHub Package Registry as `@guia-da-alma/ds`

> Publishing requires a valid `NPM_TOKEN` (GitHub Personal Access Token with `write:packages` scope) set in your environment or CI secrets.

### Release readiness gate

Run the package gate before dashboard adoption:

```bash
pnpm build
pnpm test:release-readiness
pnpm build-storybook
pnpm pack --json --pack-destination /tmp
```

The gate must prove that `dist/styles.css`, `dist/tokens.css`, `dist/tokens/*`, ESM/CJS bundles, and declaration files are present and included in the package tarball. Release-relevant package, token, or export changes require a `.changeset/*.md` file and a changelog entry from the Changesets release flow.

Current dashboard adoption is intentionally staged:

| Item | Version |
|---|---|
| Local package version: 0.1.6 | `design-system/package.json` |
| Dashboard dependency: 0.1.6 | `professional-frontend/package.json` |

Do not update `professional-frontend` to a new DS version until the DS build, DS tests, Storybook build, dashboard install, dashboard tests, and manual or visual route regression have all passed.

---

## Consuming the Package

### 1. Authenticate with GitHub Package Registry

Add or update `~/.npmrc` (or the project's `.npmrc`):

```
//npm.pkg.github.com/:_authToken=YOUR_GITHUB_TOKEN
@guia-da-alma:registry=https://npm.pkg.github.com
```

### 2. Install

```bash
pnpm add @guia-da-alma/ds
```

Peer dependencies (install separately if not present):

```bash
pnpm add react react-dom
pnpm add -D tailwindcss
```

### 3. Set up styles

Import the package styles in your app's global CSS entry:

```css
@import '@guia-da-alma/ds/styles';
```

Or in your Tailwind CSS file:

```css
@import 'tailwindcss';
@import '@guia-da-alma/ds/styles';
```

### 4. Wrap your app

```tsx
import { ThemeProvider, TooltipProvider } from '@guia-da-alma/ds'

export function App() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="my-app-theme">
      <TooltipProvider>
        {/* your app */}
      </TooltipProvider>
    </ThemeProvider>
  )
}
```

### 5. Use components

```tsx
import { Button, Input, useToast } from '@guia-da-alma/ds'
```
